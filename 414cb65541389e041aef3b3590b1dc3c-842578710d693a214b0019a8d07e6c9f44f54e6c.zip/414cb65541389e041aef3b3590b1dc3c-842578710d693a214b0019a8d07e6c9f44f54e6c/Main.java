void main(){
    //make array, queue, and scanner :)
    int[] arr = {1,5,34,2,15,2763};
    Queue<Integer> q = new LinkedList<>();
    Scanner umm = new Scanner(System.in);
    while (true){
        //Request an Input :P
        IO.println("""
                What would you like to do?
                1. Add
                2. Remove
                3. Peek
                4. Size
                5. isEmpty
                6. Exit""");
        int choice = umm.nextInt();
        //METHODS!!!
        if (choice == 1){
            Que.add(arr,q);
        }
        else if (choice == 2){
            Que.remove(arr,q);
        }
        else if (choice == 3){
            Que.peek(arr,q);
        }
        else if (choice == 4){
            Que.size(arr,q);
        }
        else if (choice == 5){
            Que.isEmpty(arr,q);
        }
        //To leave the code
        else if (choice == 6){
            IO.println("Exiting...");
            System.exit(0);
        }
        //Makes sure valid inputs are made
        else{
            IO.println("Invalid Option");
        }
    }
}
