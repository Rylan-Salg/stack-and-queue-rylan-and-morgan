//Imports :^
import java.util.LinkedList;
import java.util.Queue;
import java.util.Scanner;

public class Que {
    //Add something to the queue :|
    static void add(int[] arr, Queue<Integer> q) {
        Scanner fella = new Scanner(System.in);
        IO.println("Type a Number to Add   ");
        int in = fella.nextInt();
        q.add(in);
    }
    //Remove something from the queue X(
    static void remove(int[] arr, Queue<Integer> q){
        q.remove();
    }
    //Look at the bottom of queue :O
    static void peek(int[] arr, Queue<Integer> q){
        System.out.println(q.peek());
    }
    //Look at size of the queue :D
    static void size(int[] arr, Queue<Integer> q){
        System.out.println("Length: " + q.size());
    }
    //Look at if the queue is empty >:|
    static void isEmpty(int[] arr, Queue<Integer> q){
        System.out.println("Empty: " + q.isEmpty());
    }
}
